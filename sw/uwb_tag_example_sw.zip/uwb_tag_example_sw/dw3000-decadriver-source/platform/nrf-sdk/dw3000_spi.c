#include "sdk_config.h"
#include "nrf_gpio.h"
#include "nrfx_spim.h"
#include "nrf_delay.h"
#include "deca_device_api.h"

// ==========================================
// [1] HARDWARE CONFIGURATION
// Updated based on your schematic and compiler error
// ==========================================
#define DW_SPI_INSTANCE_ID  3   // Compiler says 'NRFX_SPIM3_INST_IDX' is valid

// Pins from your schematic (image_787ab2.png)
#define DW_PIN_SCK          31  // P0.31 (SPICLK)
#define DW_PIN_MOSI         30  // P0.30 (SPIMOSI)
#define DW_PIN_MISO         28  // P0.28 (SPIMISO)
#define DW_PIN_CS           2   // P0.02 (SPICSN)

// ==========================================

static const nrfx_spim_t dw_spi = NRFX_SPIM_INSTANCE(DW_SPI_INSTANCE_ID);

// Dummy mutex macros if not defined elsewhere
#ifndef decamutexon
#define decamutexon()  0
#define decamutexoff(x) do{}while(0)
#endif

// ---------------------------------------------------------------------------
// Initialization
// ---------------------------------------------------------------------------
int dw3000_spi_init(void)
{
    nrfx_err_t ret;

    nrfx_spim_config_t spi_config = NRFX_SPIM_DEFAULT_CONFIG;
    spi_config.sck_pin      = DW_PIN_SCK;
    spi_config.mosi_pin     = DW_PIN_MOSI;
    spi_config.miso_pin     = DW_PIN_MISO;
    spi_config.ss_pin       = NRFX_SPIM_PIN_NOT_USED; // Manually controlled
    spi_config.frequency    = NRF_SPIM_FREQ_4M;       // Start slow (4MHz)
    spi_config.mode         = NRF_SPIM_MODE_0;
    spi_config.bit_order    = NRF_SPIM_BIT_ORDER_MSB_FIRST;

    ret = nrfx_spim_init(&dw_spi, &spi_config, NULL, NULL);
    if (ret != NRFX_SUCCESS) {
        return -1;
    }

    // Configure CS Pin manually
    nrf_gpio_cfg_output(DW_PIN_CS);
    nrf_gpio_pin_set(DW_PIN_CS); // Set High (Inactive)

    // Wait a bit for chip to stabilize
    nrf_delay_ms(2);

    return 0;
}

// ---------------------------------------------------------------------------
// REQUIRED DRIVER FUNCTIONS
// ---------------------------------------------------------------------------

/*! ------------------------------------------------------------------------------------------------------------------
 * Function: writetospi()
 */
int writetospi(uint16_t headerLength, const uint8_t *headerBuffer, uint32_t bodylength, const uint8_t *bodyBuffer)
{
    decamutexon();
    nrf_gpio_pin_clear(DW_PIN_CS); // CS Low

    nrfx_spim_xfer_desc_t xfer_head = NRFX_SPIM_XFER_TX(headerBuffer, headerLength);
    nrfx_spim_xfer(&dw_spi, &xfer_head, 0);

    if (bodylength > 0)
    {
        nrfx_spim_xfer_desc_t xfer_body = NRFX_SPIM_XFER_TX(bodyBuffer, bodylength);
        nrfx_spim_xfer(&dw_spi, &xfer_body, 0);
    }

    nrf_gpio_pin_set(DW_PIN_CS);   // CS High
    decamutexoff(stat);
    return 0;
}

/*! ------------------------------------------------------------------------------------------------------------------
 * Function: readfromspi()
 */
int readfromspi(uint16_t headerLength, const uint8_t *headerBuffer, uint32_t readlength, uint8_t *readBuffer)
{
    decamutexon();
    nrf_gpio_pin_clear(DW_PIN_CS); // CS Low

    // 1. Send Header
    nrfx_spim_xfer_desc_t xfer_head = NRFX_SPIM_XFER_TX(headerBuffer, headerLength);
    nrfx_spim_xfer(&dw_spi, &xfer_head, 0);

    // 2. Read Body
    if (readlength > 0)
    {
        nrfx_spim_xfer_desc_t xfer_body = NRFX_SPIM_XFER_RX(readBuffer, readlength);
        nrfx_spim_xfer(&dw_spi, &xfer_body, 0);
    }

    nrf_gpio_pin_set(DW_PIN_CS);   // CS High
    decamutexoff(stat);
    return 0;
}

/*! ------------------------------------------------------------------------------------------------------------------
 * Function: writetospiwithcrc()
 */
int writetospiwithcrc(uint16_t headerLength, const uint8_t *headerBuffer, uint32_t bodylength, const uint8_t *bodyBuffer, uint8_t crc8)
{
    decamutexon();
    nrf_gpio_pin_clear(DW_PIN_CS); // CS Low

    // 1. Send Header
    nrfx_spim_xfer_desc_t xfer_head = NRFX_SPIM_XFER_TX(headerBuffer, headerLength);
    nrfx_spim_xfer(&dw_spi, &xfer_head, 0);

    // 2. Send Body
    if (bodylength > 0)
    {
        nrfx_spim_xfer_desc_t xfer_body = NRFX_SPIM_XFER_TX(bodyBuffer, bodylength);
        nrfx_spim_xfer(&dw_spi, &xfer_body, 0);
    }
    
    // 3. Send CRC
    nrfx_spim_xfer_desc_t xfer_crc = NRFX_SPIM_XFER_TX(&crc8, 1);
    nrfx_spim_xfer(&dw_spi, &xfer_crc, 0);

    nrf_gpio_pin_set(DW_PIN_CS);   // CS High
    decamutexoff(stat);
    return 0;
}