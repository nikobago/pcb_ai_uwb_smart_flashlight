#include "sdk_config.h"
#include "deca_device_api.h"
#include "dw3000_hw.h"
#include "nrf_delay.h"
#include "nrf_gpio.h"

// INCLUDE REGISTER DEFINITIONS
#include "dw3000_deca_regs.h" 
#include "dw3000_deca_vals.h"

#define LED_PIN  5   

// External helper functions
extern uint32_t dwt_read32bitoffsetreg(int regFileID, int regOffset);
extern void dwt_write32bitoffsetreg(int regFileID, int regOffset, uint32_t regval);

// SPI Init Prototype
extern int dw3000_spi_init(void);

// Configuration
static dwt_config_t config = {
    5, DWT_PLEN_128, DWT_PAC8, 9, 9, 1, 
    DWT_BR_6M8, DWT_PHRMODE_STD, DWT_PHRRATE_STD, 
    (129 + 8 - 8), DWT_STS_MODE_OFF, DWT_STS_LEN_64, DWT_PDOA_M0       
};

static uint8_t tx_msg[] = {0x41, 0x88, 0, 0xCA, 0xDE, 'S', 'Y', 'N', 'C', 0, 0};
static uint8_t frame_seq_nb = 0;

int main(void)
{
    // 1. Hardware Init
    dw3000_hw_init();
    dw3000_spi_init();
    
    nrf_gpio_cfg_output(LED_PIN);
    nrf_gpio_pin_clear(LED_PIN);

    // 2. Software Reset (Crucial Fix Here)
    // We pass '1' because your driver signature requires an argument.
    // dwt_softreset(int32_t reset_semaphore)
    dwt_softreset(1); 
    
    nrf_delay_ms(5);

    // 3. Initialize DW3000
    if (dwt_initialise(0x00) != DWT_SUCCESS) {
        while (1) { 
            nrf_gpio_pin_toggle(LED_PIN); 
            nrf_delay_ms(50); 
        }
    }

    // [CRITICAL] Set Trim to 0x00 to match ESP32
    dwt_setxtaltrim(0x00); 

    // 4. Configure Radio
    if (dwt_configure(&config) != DWT_SUCCESS) { 
        while (1) {}; 
    }
    
    dwt_settxantennadelay(16385);
    dwt_setrxantennadelay(16385);

    // 5. Main Loop
    while (1)
    {
        nrf_gpio_pin_set(LED_PIN);

        tx_msg[2] = frame_seq_nb++;

        dwt_writetxdata(sizeof(tx_msg) - 2, tx_msg, 0); 
        dwt_writetxfctrl(sizeof(tx_msg), 0, 0);
        dwt_starttx(DWT_START_TX_IMMEDIATE);

        // Watchdog Loop
        int timeout = 50000;
        uint32_t status = 0;
        do {
            status = dwt_read32bitoffsetreg(SYS_STATUS_ID, 0);
            timeout--;
        } while (!(status & SYS_STATUS_TXFRS_BIT_MASK) && timeout > 0);

        if (timeout <= 0) {
            dwt_write32bitoffsetreg(SYS_STATUS_ID, 0, 0xFFFFFFFF);
            
            // Fix reset call here too
            dwt_softreset(1); 
            
            dwt_initialise(0x00);
            dwt_configure(&config);
            dwt_setxtaltrim(0x00);
        } else {
            dwt_write32bitoffsetreg(SYS_STATUS_ID, 0, SYS_STATUS_TXFRS_BIT_MASK);
        }

        nrf_gpio_pin_clear(LED_PIN);
        nrf_delay_ms(250); 
    }
}