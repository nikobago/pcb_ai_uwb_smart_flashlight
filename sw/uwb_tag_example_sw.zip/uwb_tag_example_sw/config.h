#ifndef CONFIG_H
#define CONFIG_H

#include "nrf_gpio.h"

// ==========================================
// DW3000 Pin Configuration (nRF52833 Custom Board)
// ==========================================

// --- Control Pins (From your Schematic) ---
// RSTN is mapped to P0.29
#define CONFIG_DW3000_GPIO_RESET   29

// IRQ is mapped to P0.03
#define CONFIG_DW3000_GPIO_IRQ     3

// WAKEUP: Set to -1 if unused (or mapped to CS)
#define CONFIG_DW3000_GPIO_WAKEUP  -1

// --- SPI Bus Pins ---
// SPICSN (Chip Select) is P0.02
#define CONFIG_DW3000_SPI_CS       2

// SPICLK (Clock) is P0.31 
// NOTE: Driver calls this "CLK", not "SCK"
#define CONFIG_DW3000_SPI_CLK      31

// SPIMOSI (Master Out Slave In) is P0.30
#define CONFIG_DW3000_SPI_MOSI     30

// SPIMISO (Master In Slave Out) is P0.28
#define CONFIG_DW3000_SPI_MISO     28

// --- SPI Settings ---
// The driver requires a Max MHz setting (8MHz is standard for DW3000)
#define CONFIG_DW3000_SPI_MAX_MHZ  8

// --- SPI Hardware Instance ---
// Uses SPI3 (High speed SPI on nRF52833)
#define CONFIG_DW3000_SPI_IDX      3

// --- Interrupt Priority ---
// Defines the priority for the DW3000 IRQ (APP_IRQ_PRIORITY_LOW is safe)
#define NRFX_SPIM_DEFAULT_CONFIG_IRQ_PRIORITY 6

#endif // CONFIG_H