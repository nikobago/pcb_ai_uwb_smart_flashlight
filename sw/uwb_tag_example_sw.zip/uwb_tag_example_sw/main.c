#include "sdk_config.h"
#include "deca_device_api.h"
#include "dw3000_hw.h"
#include "nrf_delay.h"
#include "nrf_gpio.h"
#include "dw3000_deca_regs.h" 
#include "dw3000_deca_vals.h"

#define LED_PIN  5   

extern uint32_t dwt_read32bitoffsetreg(int regFileID, int regOffset);
extern void dwt_write32bitoffsetreg(int regFileID, int regOffset, uint32_t regval);
extern int dw3000_spi_init(void);


static dwt_config_t config = {
    5,                // Channel 5
    DWT_PLEN_1024,    // 1024 Symbol Preamble
    DWT_PAC32,        // PAC 32
    9, 9,             // Codes
    0,                // SFD Mode 0
    DWT_BR_850K,      // 850 kbps
    DWT_PHRMODE_STD,  
    DWT_PHRRATE_STD,  
    (1025 + 64 - 32), 
    DWT_STS_MODE_OFF, 
    DWT_STS_LEN_64,   
    DWT_PDOA_M0       
};

int main(void)
{
    dw3000_hw_init();
    dw3000_spi_init();
    nrf_gpio_cfg_output(LED_PIN);
    nrf_gpio_pin_clear(LED_PIN);

    dwt_softreset(1); 
    nrf_delay_ms(5);

    if (dwt_initialise(0x00) != DWT_SUCCESS) {
        while (1) { nrf_gpio_pin_toggle(LED_PIN); nrf_delay_ms(50); }
    }


    dwt_setxtaltrim(0x18); 

    if (dwt_configure(&config) != DWT_SUCCESS) { while (1); }
    
   
    dwt_rxenable(DWT_START_RX_IMMEDIATE);

    while (1)
    {
        uint32_t status = dwt_read32bitoffsetreg(SYS_STATUS_ID, 0);

        if (status & SYS_STATUS_RXFCG_BIT_MASK)
        {
            dwt_write32bitoffsetreg(SYS_STATUS_ID, 0, SYS_STATUS_RXFCG_BIT_MASK);
            nrf_gpio_pin_toggle(LED_PIN); // BLINK!
            dwt_rxenable(DWT_START_RX_IMMEDIATE);
        }
        else if (status & (SYS_STATUS_RXFCE_BIT_MASK | SYS_STATUS_RXFSL_BIT_MASK | SYS_STATUS_RXPHD_BIT_MASK))
        {
            dwt_write32bitoffsetreg(SYS_STATUS_ID, 0, 0xFFFFFFFF);
            dwt_rxenable(DWT_START_RX_IMMEDIATE);
        }
    }
}