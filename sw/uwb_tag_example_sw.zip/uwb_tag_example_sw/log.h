#ifndef LOG_H
#define LOG_H

// Define these as empty macros so the compiler deletes the code.
// This completely removes all dependencies on the Nordic Logger.

#define LOG_INF(...)
#define LOG_ERR(...)
#define LOG_WRN(...)
#define LOG_DBG(...)

#endif // LOG_H